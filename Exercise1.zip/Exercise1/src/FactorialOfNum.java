
public class FactorialOfNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i=1 , f=1; // i for the loop and f is the fact output
int n=5; //number to calculate the factorial of

for(i=1;i<=n;i++){    
    f=f*i;    // calculate factorial 
}    
System.out.print(f); // print the output
	}

}
 