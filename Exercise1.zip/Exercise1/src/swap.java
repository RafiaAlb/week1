
public class swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int m =9 , n=5; // input two numbers 

int store = m; //store the value of m in "store"

m = n; // set the value of n to m

n = store; // set the old value of m to n

System.out.println("n= " +n);
System.out.println("m= " +m);

	}

}
