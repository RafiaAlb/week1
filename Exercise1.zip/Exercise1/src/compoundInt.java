
public class compoundInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
double p=1200; //set principal amount
double t=2 ; //set time span
double r=5.4; //set rate 

double CI= p*(Math.pow((1 + r / 100), t)); //calculate the compound interest

System.out.print(CI); // print compound interest


	}

}
